Group A 
Name: 
Aman Gour (120050030) 
Jaseem Umar (120050083)

Group B
 Name: 
Pintu Lal Meena (120050018)
Ravi Verma (120050027)